const STORAGE_KEY = 'amerit_fleet_ai_portal_state';

const demoSeed = {
  currentRole: 'Service Advisor',
  selectedRoId: 'RO-1048',
  lastPacket: '',
  repairOrders: [
    {
      id: 'RO-1048',
      unit: '4V4NC9UG2NN318404',
      complaint: 'Air leak / dash gauges',
      priority: 'High',
      rawNotes: 'Found air leak at foot brake valve. Multiple fittings leaking. Dash gauge fittings leaking. Needs gauges and tank fittings. 3 hr repair plus 1.25 hr fittings.',
      photos: [],
      createdAt: nowMinus(9),
      updatedAt: nowMinus(2),
      status: 'Missing Info',
      compliance: { photos: false, diag: true, unitPhoto: false, amazonReady: false },
      ai: {},
      history: [],
      techRequests: ['Upload clear photos of leaking fittings and dash gauge area.', 'Confirm exact quantity of fittings and part numbers if available.']
    },
    {
      id: 'RO-1055',
      unit: '1FVAHFFT7PHNW2382',
      complaint: 'DOT tire / brake',
      priority: 'Critical',
      rawNotes: 'Both steer tires at 4/32 and 3/32. Steer brake pads low to requirements. Replace both steer tires and both steer pads.',
      photos: ['sample'],
      createdAt: nowMinus(14),
      updatedAt: nowMinus(5),
      status: 'Ready for Review',
      compliance: { photos: true, diag: true, unitPhoto: true, amazonReady: true },
      ai: {},
      history: [],
      techRequests: []
    },
    {
      id: 'RO-1058',
      unit: 'Trailer-73219',
      complaint: 'Conspicuity / light / panel rivets',
      priority: 'Normal',
      rawNotes: 'Removed old conspicuity tape. Clean surface before applying new tape. Drill out broken rivets on upper and lower panel. Replace broken turn signal light.',
      photos: ['sample','sample2'],
      createdAt: nowMinus(20),
      updatedAt: nowMinus(1),
      status: 'Approved',
      compliance: { photos: true, diag: true, unitPhoto: true, amazonReady: true },
      ai: {},
      history: [],
      techRequests: []
    }
  ],
  timeline: []
};

function nowMinus(minutes){return new Date(Date.now()-minutes*60000).toISOString();}
function deepClone(x){return JSON.parse(JSON.stringify(x));}
function loadState(){
  const existing = localStorage.getItem(STORAGE_KEY);
  if(existing) return JSON.parse(existing);
  const state = deepClone(demoSeed);
  state.repairOrders = state.repairOrders.map(runAiWorkflow);
  state.timeline = [
    logEntry('System initialized with demo data.'),
    logEntry('AI pre-processed 3 seeded repair orders.'),
  ];
  saveState(state);
  return state;
}
function saveState(state){localStorage.setItem(STORAGE_KEY, JSON.stringify(state));}
let state = loadState();

const els = {
  navBtns: [...document.querySelectorAll('.nav-btn')],
  views: [...document.querySelectorAll('.view')],
  viewTitle: document.getElementById('viewTitle'),
  viewSubtitle: document.getElementById('viewSubtitle'),
  userName: document.getElementById('userName'),
  userRole: document.getElementById('userRole'),
  statsGrid: document.getElementById('statsGrid'),
  roTableBody: document.getElementById('roTableBody'),
  timeline: document.getElementById('timeline'),
  roForm: document.getElementById('roForm'),
  aiPreview: document.getElementById('aiPreview'),
  photoInput: document.getElementById('photoInput'),
  photoPreview: document.getElementById('photoPreview'),
  techQueue: document.getElementById('techQueue'),
  techRoSelect: document.getElementById('techRoSelect'),
  techResponseForm: document.getElementById('techResponseForm'),
  approvalQueue: document.getElementById('approvalQueue'),
  historyPanel: document.getElementById('historyPanel'),
  packetRoSelect: document.getElementById('packetRoSelect'),
  packetPreview: document.getElementById('packetPreview'),
  packetStatus: document.getElementById('packetStatus'),
  searchInput: document.getElementById('searchInput'),
  resetDemo: document.getElementById('resetDemo'),
  buildPacketBtn: document.getElementById('buildPacketBtn'),
  downloadPacketBtn: document.getElementById('downloadPacketBtn'),
  exportQueue: document.getElementById('exportQueue'),
  loginBanner: document.getElementById('loginBanner')
};

function formatTime(iso){return new Date(iso).toLocaleString();}
function badge(text, cls=''){return `<span class="badge ${cls}">${text}</span>`;}
function logEntry(message){return {message, time: new Date().toISOString()};}
function slug(str){return str.toLowerCase().replace(/[^a-z0-9]+/g,'-');}

function aiGenerate(rawNotes){
  const text = (rawNotes || '').toLowerCase();
  const findings=[]; const parts=[]; const labor=[]; let severity='Normal';
  const yes = (...words)=>words.some(w=>text.includes(w));
  if(yes('air leak','leaking fitting','gauge')){
    findings.push('Inspection found air system leaks affecting brake or dash air components.');
    parts.push('Air fittings as needed');
    if(text.includes('gauge')) parts.push('Dash air gauge(s)');
    labor.push('Section 1 - Diagnose air leak source');
    labor.push('Section 2 - Replace leaking air fittings / connections');
    if(text.includes('gauge')) labor.push('Section 3 - Replace leaking dash gauge components');
    severity='High';
  }
  if(yes('tire','4/32','3/32','chunking','flat spot')){
    findings.push('Tire inspection found replacement criteria due to wear or damage.');
    parts.push('Tire(s) at failed positions');
    labor.push('Section 1 - Replace failed tire positions');
    severity='Critical';
  }
  if(yes('brake pad','brake shoe','cracked')){
    findings.push('Brake inspection identified worn or damaged braking components requiring replacement.');
    parts.push('Brake pads / shoes as required');
    labor.push('Section 2 - Replace brake friction components');
    severity='Critical';
  }
  if(yes('light','turn signal')){
    findings.push('Lighting system has failed component(s) requiring replacement.');
    parts.push('Replacement light assembly');
    labor.push('Section - Replace lighting component and verify operation');
  }
  if(yes('rivet','panel','conspicuity')){
    findings.push('Trailer body / panel repair is required to restore secure mounting and visibility items.');
    parts.push('Rivets and conspicuity tape as required');
    labor.push('Section - Repair panel mounting and replace conspicuity tape');
  }
  if(findings.length===0){
    findings.push('Technician notes reviewed. Additional detail may be required before submission.');
    labor.push('Section 1 - Diagnostic review');
  }
  const customerNotes = findings.join(' ') + ' Repairs are recommended to restore safe and compliant operation.';
  const advisorNotes = 'AI parsed technician notes and drafted estimate structure. Verify labor times, quantity of parts, and supporting photos before submission.';
  const compliance = {
    diag: rawNotes.trim().length > 35,
    photos: false,
    unitPhoto: false,
    amazonReady: false
  };
  const followUps = [];
  if(text.includes('replace') && !yes('because','due to','found')) followUps.push('Clarify failure reason supporting replacement recommendation.');
  if(yes('tire') && !yes('4/32','3/32','cut','chunk','flat spot','nail','pull point')) followUps.push('Add tread depth or damage details for tire replacement justification.');
  if(yes('air leak') && !yes('fitting','valve','gauge','behind the dash')) followUps.push('Identify the exact leak source and affected component.');
  return {customerNotes, advisorNotes, estimateSections:labor, parts, severity, compliance, followUps};
}

function runAiWorkflow(ro){
  const ai = aiGenerate(ro.rawNotes || '');
  const photoCount = (ro.photos || []).length;
  ro.ai = ai;
  ro.compliance.diag = ai.compliance.diag;
  ro.compliance.photos = photoCount > 0;
  ro.compliance.unitPhoto = photoCount > 1 || photoCount===1 && ro.unit.toLowerCase().includes('trailer');
  ro.compliance.amazonReady = ro.compliance.diag && ro.compliance.photos && ro.ai.followUps.length===0;
  ro.status = ro.compliance.amazonReady ? 'Ready for Review' : 'Missing Info';
  if((ro.history || []).length===0) ro.history = [];
  ro.history.push({
    time: new Date().toISOString(),
    customerNotes: ro.ai.customerNotes,
    estimateSections: [...ro.ai.estimateSections],
    parts: [...ro.ai.parts],
    status: ro.status
  });
  ro.techRequests = [];
  if(!ro.compliance.photos) ro.techRequests.push('Upload clear photos of the failed component(s).');
  if(!ro.compliance.unitPhoto) ro.techRequests.push('Upload unit ID photo to support submission package.');
  ro.techRequests.push(...ro.ai.followUps);
  ro.updatedAt = new Date().toISOString();
  return ro;
}

function render(){
  saveState(state);
  els.userName.textContent = `Demo ${state.currentRole}`;
  els.userRole.textContent = state.currentRole;
  renderStats(); renderTable(); renderTimeline(); renderSelects(); renderTechQueue(); renderApproval(); renderHistory(); renderAiPreview(); renderPacketStatus();
}

function renderStats(){
  const ros = filteredRos();
  const stats = [
    ['Open ROs', ros.length],
    ['Missing Info', ros.filter(r=>r.status==='Missing Info').length],
    ['Ready for Review', ros.filter(r=>r.status==='Ready for Review').length],
    ['Approved / Closed', ros.filter(r=>['Approved','Closed'].includes(r.status)).length],
  ];
  els.statsGrid.innerHTML = stats.map(([label,value])=>`<div class="stat"><div class="small-label">${label}</div><div class="number">${value}</div></div>`).join('');
}
function complianceLabel(ro){return ro.compliance.amazonReady ? badge('Ready','ready') : badge('Hold','hold');}
function statusClass(status){if(status==='Ready for Review') return 'review'; if(status==='Missing Info') return 'hold'; if(status==='Approved'||status==='Closed') return 'closed'; return '';}
function filteredRos(){
  const q = els.searchInput.value.trim().toLowerCase();
  if(!q) return state.repairOrders;
  return state.repairOrders.filter(r => [r.id,r.unit,r.status,r.complaint].join(' ').toLowerCase().includes(q));
}
function renderTable(){
  els.roTableBody.innerHTML = filteredRos().map(ro=>`<tr data-id="${ro.id}"><td>${ro.id}</td><td>${ro.unit}</td><td>${badge(ro.status, statusClass(ro.status))}</td><td>${complianceLabel(ro)}</td><td>${formatTime(ro.updatedAt)}</td></tr>`).join('');
  [...els.roTableBody.querySelectorAll('tr')].forEach(tr=>tr.onclick=()=>{state.selectedRoId=tr.dataset.id; switchView('new-ro'); render(); fillForm(selectedRo());});
}
function renderTimeline(){
  const all = [...state.timeline].reverse().slice(0,14);
  els.timeline.innerHTML = all.map(item=>`<div class="timeline-item"><strong>${item.message}</strong><div class="muted">${formatTime(item.time)}</div></div>`).join('');
}
function renderSelects(){
  const options = state.repairOrders.map(ro=>`<option value="${ro.id}" ${ro.id===state.selectedRoId?'selected':''}>${ro.id} - ${ro.unit}</option>`).join('');
  els.techRoSelect.innerHTML = options;
  els.packetRoSelect.innerHTML = options;
}
function selectedRo(){return state.repairOrders.find(r=>r.id===state.selectedRoId) || state.repairOrders[0];}
function fillForm(ro){
  if(!ro) return;
  const f = els.roForm;
  f.roNumber.value = ro.id; f.unit.value = ro.unit; f.complaint.value = ro.complaint; f.priority.value = ro.priority; f.rawNotes.value = ro.rawNotes;
  renderPhotoPreview(ro.photos || []);
}
function renderPhotoPreview(photos){
  els.photoPreview.innerHTML = (photos||[]).map((src,i)=> src.startsWith('data:') ? `<img class="photo-thumb" src="${src}" alt="photo ${i+1}" />` : `<div class="photo-thumb" style="display:grid;place-items:center;background:#16233c;color:#9fb1d8">Photo ${i+1}</div>`).join('');
}
function renderAiPreview(){
  const ro = selectedRo();
  if(!ro){ els.aiPreview.innerHTML=''; return; }
  const ai = ro.ai || {estimateSections:[],parts:[],followUps:[]};
  els.aiPreview.innerHTML = `
    <div class="ai-box"><div class="small-label">Customer Notes</div><div>${ai.customerNotes || 'Run AI workflow to generate notes.'}</div></div>
    <div class="ai-box"><div class="small-label">Advisor Notes</div><div>${ai.advisorNotes || '-'}</div></div>
    <div class="ai-box"><div class="small-label">Estimate Sections</div><div>${(ai.estimateSections||[]).map(s=>`<div>• ${s}</div>`).join('')}</div></div>
    <div class="ai-box"><div class="small-label">Parts Suggestions</div><div>${(ai.parts||[]).map(s=>`<div>• ${s}</div>`).join('')}</div></div>
    <div class="ai-box"><div class="small-label">Compliance</div><div class="subgrid"><div class="pill">Diag: ${ro.compliance.diag ? 'Yes':'No'}</div><div class="pill">Photos: ${ro.compliance.photos ? 'Yes':'No'}</div><div class="pill">Unit Photo: ${ro.compliance.unitPhoto ? 'Yes':'No'}</div><div class="pill">Amazon Ready: ${ro.compliance.amazonReady ? 'Yes':'No'}</div></div></div>
    <div class="ai-box"><div class="small-label">AI Follow Ups</div><div>${(ro.techRequests||[]).length ? ro.techRequests.map(s=>`<div>• ${s}</div>`).join('') : 'No follow-up needed.'}</div></div>`;
}
function renderTechQueue(){
  const ros = state.repairOrders.filter(r=>r.status==='Missing Info' || (r.techRequests||[]).length);
  els.techQueue.innerHTML = ros.map(ro=>`<div class="queue-item"><h4>${ro.id} - ${ro.unit}</h4><div class="muted">${ro.complaint}</div><div>${(ro.techRequests||[]).map(x=>`<div>• ${x}</div>`).join('')}</div></div>`).join('') || '<div class="card">No technician follow-ups pending.</div>';
}
function renderApproval(){
  const ros = state.repairOrders.filter(r=>['Ready for Review','Approved'].includes(r.status));
  els.approvalQueue.innerHTML = ros.map(ro=>`<div class="queue-item"><h4>${ro.id} - ${ro.unit}</h4><div class="muted">${ro.ai.customerNotes || ''}</div><div class="actions-row" style="margin-top:10px"><button onclick="approveRo('${ro.id}')">Manager Approve</button><button class="ghost" onclick="returnToTech('${ro.id}')">Return to Tech</button></div></div>`).join('') || '<div class="card">Nothing in manager queue.</div>';
}
function renderHistory(){
  const ro = selectedRo();
  if(!ro){els.historyPanel.innerHTML=''; return;}
  els.historyPanel.innerHTML = (ro.history||[]).slice().reverse().map((h,i)=>`<div class="history-item"><h4>Snapshot ${ro.history.length-i}</h4><div class="muted">${formatTime(h.time)} | ${h.status}</div><div><strong>Notes:</strong> ${h.customerNotes}</div><div><strong>Sections:</strong> ${(h.estimateSections||[]).join('; ')}</div><div><strong>Parts:</strong> ${(h.parts||[]).join('; ')}</div></div>`).join('') || '<div class="card">No estimate history yet.</div>';
}
function renderPacketStatus(){
  const ro = selectedRo();
  if(!ro) return;
  els.packetStatus.textContent = ro.compliance.amazonReady ? 'This RO meets the demo rules for packet generation.' : 'This RO is still missing required support. Packet can still be previewed as draft.';
}

function switchView(view){
  els.navBtns.forEach(btn=>btn.classList.toggle('active', btn.dataset.view===view));
  els.views.forEach(v=>v.classList.toggle('active', v.id===`${view}View`));
  const map={dashboard:['Dashboard','Track repair orders, AI actions, and submission readiness.'],'new-ro':['New RO','Create or update repair orders and run AI drafting.'],'technician':['Technician Portal','Respond to AI follow-up requests and add field detail.'],'manager':['Manager Approval','Review estimate snapshots and approve or return work.'],'packet':['Amazon Packet Builder','Create a submission-ready JSON packet from the selected RO.'],'settings':['Settings','Role simulation and demo controls.']};
  els.viewTitle.textContent=map[view][0]; els.viewSubtitle.textContent=map[view][1];
}

function upsertRo(formData, photos){
  let ro = state.repairOrders.find(r=>r.id===formData.roNumber);
  if(!ro){
    ro = {id: formData.roNumber, unit: '', complaint:'', priority:'Normal', rawNotes:'', photos:[], createdAt:new Date().toISOString(), updatedAt:new Date().toISOString(), status:'Draft', compliance:{photos:false,diag:false,unitPhoto:false,amazonReady:false}, ai:{}, history:[], techRequests:[]};
    state.repairOrders.unshift(ro);
    state.timeline.push(logEntry(`Created ${ro.id}.`));
  }
  ro.unit = formData.unit; ro.complaint=formData.complaint; ro.priority=formData.priority; ro.rawNotes=formData.rawNotes; if(photos?.length) ro.photos = photos; state.selectedRoId = ro.id;
  runAiWorkflow(ro);
  state.timeline.push(logEntry(`Saved and AI-processed ${ro.id}.`));
}

function buildPacket(ro){
  const packet = {
    roNumber: ro.id,
    unit: ro.unit,
    complaint: ro.complaint,
    priority: ro.priority,
    status: ro.status,
    customerNotes: ro.ai.customerNotes,
    advisorNotes: ro.ai.advisorNotes,
    estimateSections: ro.ai.estimateSections,
    suggestedParts: ro.ai.parts,
    compliance: ro.compliance,
    requestedFollowUps: ro.techRequests,
    photoCount: ro.photos.length,
    historyCount: ro.history.length,
    generatedAt: new Date().toISOString(),
    submitReady: ro.compliance.amazonReady
  };
  return JSON.stringify(packet,null,2);
}

function approveRo(id){
  const ro = state.repairOrders.find(r=>r.id===id); if(!ro) return;
  ro.status='Approved'; ro.updatedAt=new Date().toISOString(); state.timeline.push(logEntry(`Manager approved ${id}.`)); render();
}
window.approveRo = approveRo;
function returnToTech(id){
  const ro = state.repairOrders.find(r=>r.id===id); if(!ro) return;
  ro.status='Missing Info'; ro.techRequests.push('Manager requested final review detail before approval.'); ro.updatedAt=new Date().toISOString(); state.timeline.push(logEntry(`Returned ${id} to technician / advisor workflow.`)); render();
}
window.returnToTech = returnToTech;

els.navBtns.forEach(btn=>btn.addEventListener('click', ()=>switchView(btn.dataset.view)));
[...document.querySelectorAll('.role-btn')].forEach(btn=>btn.addEventListener('click', ()=>{state.currentRole=btn.dataset.role; state.timeline.push(logEntry(`Switched role to ${state.currentRole}.`)); render();}));
els.searchInput.addEventListener('input', render);
els.resetDemo.addEventListener('click', ()=>{localStorage.removeItem(STORAGE_KEY); state=loadState(); render(); fillForm(selectedRo());});
els.exportQueue.addEventListener('click', ()=>{
  const blob = new Blob([JSON.stringify(state.repairOrders,null,2)], {type:'application/json'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='ro-queue.json'; a.click(); URL.revokeObjectURL(a.href);
});

els.roForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(els.roForm).entries());
  const ro = state.repairOrders.find(r=>r.id===fd.roNumber);
  const photos = ro?.photos || [];
  upsertRo(fd, photos);
  render(); fillForm(selectedRo());
});
document.getElementById('runAiFromForm').addEventListener('click', ()=>{
  const fd = Object.fromEntries(new FormData(els.roForm).entries());
  const ro = state.repairOrders.find(r=>r.id===fd.roNumber);
  upsertRo(fd, ro?.photos || []);
  state.timeline.push(logEntry(`Manual AI workflow run for ${fd.roNumber}.`));
  render(); fillForm(selectedRo());
});

function loadSample(type){
  if(type==='air'){
    els.roForm.roNumber.value='RO-1061';
    els.roForm.unit.value='4V4NC9UG2NN318404';
    els.roForm.complaint.value='Air leak and gauge repair';
    els.roForm.priority.value='High';
    els.roForm.rawNotes.value='Found audible air leaks from behind the dash at dash air gauge fittings. Gauges need replacement. Also found leaking fittings at air tanks and foot brake valve. Repair includes 3 hours for gauge replacement and 1.25 hours for fittings.';
  } else {
    els.roForm.roNumber.value='RO-1062';
    els.roForm.unit.value='1FVAHFFT7PHNW2382';
    els.roForm.complaint.value='DOT steer tires and pads';
    els.roForm.priority.value='Critical';
    els.roForm.rawNotes.value='Both steer tires reading 4/32 and 3/32 and require replacement per DOT. Both steer brake pads are low to requirement and need replacement. Uploading photos of tread and brake condition.';
  }
}
document.getElementById('loadAirLeakSample').onclick=()=>loadSample('air');
document.getElementById('loadDotSample').onclick=()=>loadSample('dot');

els.photoInput.addEventListener('change', async (e)=>{
  const files = [...e.target.files];
  const roNum = els.roForm.roNumber.value || state.selectedRoId;
  if(!roNum) return;
  const images = await Promise.all(files.map(file=>new Promise(resolve=>{const reader=new FileReader(); reader.onload=()=>resolve(reader.result); reader.readAsDataURL(file);} )));
  let ro = state.repairOrders.find(r=>r.id===roNum);
  if(!ro){
    ro = {id: roNum, unit: els.roForm.unit.value || '', complaint: els.roForm.complaint.value || '', priority: els.roForm.priority.value || 'Normal', rawNotes: els.roForm.rawNotes.value || '', photos:[], createdAt:new Date().toISOString(), updatedAt:new Date().toISOString(), status:'Draft', compliance:{photos:false,diag:false,unitPhoto:false,amazonReady:false}, ai:{}, history:[], techRequests:[]};
    state.repairOrders.unshift(ro);
  }
  ro.photos = (ro.photos||[]).concat(images);
  runAiWorkflow(ro);
  state.selectedRoId = ro.id;
  state.timeline.push(logEntry(`Uploaded ${images.length} photo(s) to ${ro.id}.`));
  render(); fillForm(selectedRo());
});

els.techResponseForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  const fd = Object.fromEntries(new FormData(els.techResponseForm).entries());
  const ro = state.repairOrders.find(r=>r.id===els.techRoSelect.value); if(!ro) return;
  ro.rawNotes += `\nTECH UPDATE (${fd.updateType}): ${fd.response}`;
  runAiWorkflow(ro);
  state.timeline.push(logEntry(`Technician updated ${ro.id}: ${fd.updateType}.`));
  els.techResponseForm.reset();
  render();
});

els.buildPacketBtn.addEventListener('click', (e)=>{
  e.preventDefault();
  const ro = state.repairOrders.find(r=>r.id===els.packetRoSelect.value); if(!ro) return;
  state.selectedRoId = ro.id;
  state.lastPacket = buildPacket(ro);
  els.packetPreview.textContent = state.lastPacket;
  state.timeline.push(logEntry(`Built Amazon packet preview for ${ro.id}.`));
  render();
});
els.downloadPacketBtn.addEventListener('click', ()=>{
  const ro = state.repairOrders.find(r=>r.id===els.packetRoSelect.value) || selectedRo();
  const packet = state.lastPacket || buildPacket(ro);
  const blob = new Blob([packet], {type:'application/json'});
  const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`${slug(ro.id)}-amazon-packet.json`; a.click(); URL.revokeObjectURL(a.href);
});

function init(){
  render();
  fillForm(selectedRo());
  els.packetPreview.textContent = state.lastPacket || buildPacket(selectedRo());
  els.loginBanner.classList.remove('hidden');
  switchView('dashboard');
}
init();
