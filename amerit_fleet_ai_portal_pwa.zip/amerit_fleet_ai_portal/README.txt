Open index.html in a browser, or host the folder on GitHub Pages / Netlify / Vercel for the best iPhone experience. Add to Home Screen from Safari after hosting.
